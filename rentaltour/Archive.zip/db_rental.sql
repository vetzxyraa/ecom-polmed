SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+07:00";

-- 1. Tabel Admin
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
);

-- 2. Tabel Mobil (Generic)
CREATE TABLE `mobil` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `merk` varchar(50) NOT NULL,
  `transmisi` varchar(20) NOT NULL,
  `kursi` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

-- 3. Tabel Tour (Generic)
CREATE TABLE `paket_tour` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `durasi` varchar(50) NOT NULL,
  `harga` int(11) NOT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

-- 4. Tabel Booking
CREATE TABLE `booking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipe` enum('Mobil','Tour') NOT NULL,
  `item_id` int(11) NOT NULL,
  `nama_pemesan` varchar(100) NOT NULL,
  `kontak` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `qty` int(11) NOT NULL, 
  `catatan` text DEFAULT NULL,
  `total_harga` int(11) NOT NULL,
  `status` enum('Pending','Confirmed') NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`id`)
);

-- DATA DUMMY GENERIC
-- Login Admin: admin / admin123
INSERT INTO `admin` (`username`, `password`) VALUES ('admin', '$2y$10$Be4.Be4.Be4.Be4.Be4.Be4.Be4.Be4.Be4.Be4.Be4.Be4.Be4.Be4');

-- Data Mobil Simple
INSERT INTO `mobil` (`nama`, `merk`, `transmisi`, `kursi`, `harga`, `gambar`) VALUES
('Mobil Keluarga 1', 'Brand A', 'Manual', 7, 300000, ''),
('Mobil City Car', 'Brand B', 'Matic', 4, 400000, ''),
('Mobil Premium', 'Brand C', 'Matic', 7, 800000, ''),
('Minibus Wisata', 'Brand D', 'Manual', 12, 1200000, '');

-- Data Tour Simple
INSERT INTO `paket_tour` (`nama`, `durasi`, `harga`, `gambar`) VALUES
('Paket Wisata A', '1 Hari', 500000, ''),
('Paket Wisata B', '3 Hari', 1500000, '');

COMMIT;