<?php include 'config/db.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rental Mobil Profesional</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="icon" href="assets/img/favicon.png" type="image/png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body>

    <div class="bg-light border-bottom py-2 small text-muted">
        <div class="container d-flex justify-content-between align-items-center">
            <div>
                <i class="bi bi-envelope-fill me-2"></i> info@rentalmobil.com
                <span class="mx-3">|</span>
                <i class="bi bi-geo-alt-fill me-2"></i> Jl. Raya Utama No. 88, Kota Besar
            </div>
            <div class="d-none d-md-block">
                <i class="bi bi-instagram me-3"></i>
                <i class="bi bi-facebook me-3"></i>
                <i class="bi bi-whatsapp"></i>
            </div>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg sticky-top bg-white border-bottom">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">Rental<span style="color:#999">Mobil.</span></a>
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto gap-2">
                    <li class="nav-item"><a class="nav-link" href="pages/mobil.php">List Mobil</a></li>
                    <li class="nav-item"><a class="nav-link" href="pages/tour.php">Paket Tour</a></li>
                    <li class="nav-item">
                        <a href="admin/index.php" class="btn btn-sm btn-dark px-3 rounded-pill">Admin</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="hero-minimal py-5">
        <div class="container text-center py-5">
            <h1 class="hero-title fw-bold display-4 mb-4">Solusi Perjalanan<br>Aman & Nyaman.</h1>
            <p class="hero-subtitle lead text-muted mx-auto mb-5" style="max-width: 700px;">
                Mitra transportasi terpercaya untuk kebutuhan bisnis dan liburan Anda. 
                Unit terbaru, bersih, dan harga transparan.
            </p>
            
            <div class="d-flex justify-content-center gap-3">
                <a href="pages/mobil.php" class="btn btn-dark btn-lg px-5 rounded-pill shadow-sm">Cari Mobil</a>
                <a href="pages/tour.php" class="btn btn-outline-dark btn-lg px-5 rounded-pill">Paket Wisata</a>
            </div>
        </div>
    </section>

    <section class="bg-light py-5">
        <div class="container py-4">
            <div class="row g-5 align-items-center">
                <div class="col-md-6">
                    <div class="bg-white rounded-4 d-flex align-items-center justify-content-center text-muted shadow-sm border" style="height: 350px;">
                        <div class="text-center">
                            <i class="bi bi-building-check" style="font-size: 4rem;"></i><br>
                            <span class="mt-2 d-block fw-bold">OFFICE & GARAGE</span>
                        </div>
                    </div><link rel="icon" href="assets/img/favicon.png" type="image/png">
                </div>
                <div class="col-md-6">
                    <h6 class="text-uppercase fw-bold text-muted mb-2">Company Profile</h6>
                    <h2 class="fw-bold mb-4">Layanan Standar Tinggi.</h2>
                    <p class="text-muted mb-4">
                        Kami hadir memberikan kemudahan sewa kendaraan dengan proses cepat dan tanpa ribet. 
                        Seluruh armada kami dirawat secara berkala di bengkel resmi.
                    </p>
                    
                    <ul class="list-unstyled">
                        <li class="mb-3 d-flex align-items-center">
                            <i class="bi bi-shield-check text-dark me-3 fs-5"></i>
                            <div><strong>Legalitas Resmi</strong> <small class="text-muted d-block">Perusahaan terdaftar dan berizin.</small></div>
                        </li>
                        <li class="mb-3 d-flex align-items-center">
                            <i class="bi bi-star-fill text-dark me-3 fs-5"></i>
                            <div><strong>Unit Tahun Muda</strong> <small class="text-muted d-block">Rata-rata usia mobil di bawah 3 tahun.</small></div>
                        </li>
                        <li class="mb-3 d-flex align-items-center">
                            <i class="bi bi-clock-history text-dark me-3 fs-5"></i>
                            <div><strong>Booking Mudah</strong> <small class="text-muted d-block">Pesan online, konfirmasi via WhatsApp.</small></div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <footer class="py-4 text-center border-top bg-white">
        <div class="container">
            <h5 class="fw-bold m-0">RentalMobil.</h5>
            <small class="text-muted d-block mt-1">Jl. Raya Utama No. 88, Kota Besar.</small>
            <small class="text-muted">&copy; 2024. All Rights Reserved.</small>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>